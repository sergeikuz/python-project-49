from brain_games.games.gcd import game_gcd


def main():
    game_gcd()


if __name__ == '__main__':
    main()
