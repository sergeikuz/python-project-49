# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'This project includes five mini-games: brain-even, brain-calc, brain-progression, brain-gcd, brain-prime.',
    'long_description': '## Brain Games: the collection of 5 math mini-games\n<hr>\n\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/sergeikuz/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/sergeikuz/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/ab58d38fde5644fe65ba/maintainability)](https://codeclimate.com/github/sergeikuz/python-project-49/maintainability)\n\n\nThis is project ["Brain Games"](https://ru.hexlet.io/programs/python/projects/49) on the Python Development course on [Hexlet.io](https://ru.hexlet.io/programs/python)\n\n### Used technologies:\n![](https://img.shields.io/badge/language-python-blue)\n![](https://img.shields.io/badge/lybrary-prompt-brightgreen)\n![](https://img.shields.io/badge/lybrary-random-orange)\n![](https://img.shields.io/badge/lybrary-math-ff67b4)\n\nThis project was built using these tools:\n\n| Tool                                                                        | Description                                             |\n|-----------------------------------------------------------------------------|---------------------------------------------------------|\n| [poetry](https://poetry.eustace.io/)                                        | "Python dependency management and packaging made easy"  |\n| [Py.Test](https://pytest.org)                                               | "A mature full-featured Python testing tool"            |\n| [Flake8](https://flake8.pycqa.org/en/latest/)               | "Your Tool For Style Guide Enforcement"|\n\n---\n## Install\n```\ngit clone https://github.com/sergeikuz/python-project-49\ncd python-project-49\nmake package-install\n```\n\n[![asciicast](https://asciinema.org/a/615503.svg)](https://asciinema.org/a/615503)\n\n\n\n### Description:\n\n**"Mind Games"** is a set of five console games based on the popular mobile brain-pumping apps. Each game asks questions that need to be answered correctly. After three correct answers, the game is considered completed. Incorrect answers end the game and prompt you to play it again. \n\n\n## They are launched with simple commands:*\n```commandline\nbrain-even\nbrain-calc\nbrain-gcd\nbrain-progression\nbrain-prime\n```\n:pencil2:*_Make sure that you have Python version 3.6 or higher installed._\n\n\n## Games:\n\n1. **brain-even:** *Determine if the number is even. You need to answer yes if the number is even, or no if it is odd.*\n\n\n[![asciicast](https://asciinema.org/a/614934.svg)](https://asciinema.org/a/614934)\n\n\n2. **brain-calc:** *You are shown a random math expression, which you need to calculate and write down the correct answer.*\n\n\n[![asciicast](https://asciinema.org/a/614985.svg)](https://asciinema.org/a/614985)\n\n\n3. **brain-gcd:** *You are shown a random numbers. And you have to calculate and enter the greatest common divisor of these numbers.*\n\n\n[![asciicast](https://asciinema.org/a/614989.svg)](https://asciinema.org/a/614989)\n\n\n4. **brain-progression:** *You are shown a random arithmetic progression. You have to calculate the forgiven number.*\n\n\n[![asciicast](https://asciinema.org/a/614987.svg)](https://asciinema.org/a/614987)\n\n\n5. **brain-prime:** *Determine if the number id prime. You need to answer yes if the number is prime, or no if it it is not this way.*\n\n\n[![asciicast](https://asciinema.org/a/614998.svg)](https://asciinema.org/a/614998)\n\n### Good luck and have a fun game! 🤚\n',
    'author': 'Sergei Kuznetsov',
    'author_email': 's8kuznetsov888@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/sergeikuz/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
