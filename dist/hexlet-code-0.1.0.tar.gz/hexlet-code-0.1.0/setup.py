# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/sergeikuz/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/sergeikuz/python-project-49/actions)\n[![Maintainability](https://api.codeclimate.com/v1/badges/ab58d38fde5644fe65ba/maintainability)](https://codeclimate.com/github/sergeikuz/python-project-49/maintainability)\n\n### GAME:\n1. [brain-even](https://asciinema.org/a/FesnuWUtAVWKbzqHtm4aLvBAM)\n2. [brain-calc](https://asciinema.org/a/1nFyGQOECgY2kvFhQEsgZ47ic)\n3. [brain-gcd](https://asciinema.org/a/EfVryCIKaMMTbZuhB7m86BJQ9)\n4. [brain-progression](https://asciinema.org/a/xsNZ3k08JJ2IiDEZbZFYSiYEm)\n',
    'author': 'Sergei Kuznetsov',
    'author_email': 's8kuznetsov888@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
