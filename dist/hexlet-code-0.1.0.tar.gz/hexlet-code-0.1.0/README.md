### Hexlet tests and linter status:
[![Actions Status](https://github.com/sergeikuz/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/sergeikuz/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/ab58d38fde5644fe65ba/maintainability)](https://codeclimate.com/github/sergeikuz/python-project-49/maintainability)

### GAME:
1. [brain-even](https://asciinema.org/a/FesnuWUtAVWKbzqHtm4aLvBAM)
